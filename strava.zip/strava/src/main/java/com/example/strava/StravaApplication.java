package com.example.strava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StravaApplication {

	public static void main(String[] args) {
		SpringApplication.run(StravaApplication.class, args);
	}

}
