package com.example.strava.entity;

public class Challenge {

}
