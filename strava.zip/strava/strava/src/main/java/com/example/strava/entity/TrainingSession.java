package com.example.strava.entity;

public class TrainingSession {

}
